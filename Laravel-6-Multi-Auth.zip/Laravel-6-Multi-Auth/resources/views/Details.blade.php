 
  <h4>{{ $product->name }}</h4>
  